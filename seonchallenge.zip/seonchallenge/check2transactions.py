import pyodbc
import geopy.distance



def connect():
    conn = pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                          'Server=79.113.62.81, 1234;'
                          'Database=seonchallenge;'
                          'UID=user;'
                          'PWD=admin;'
                          )
    cursor = conn.cursor()
    return cursor


def getdetails(transaction):
    querycursor = connect()
    query = "SELECT * FROM transtable WHERE transactionid = '" + transaction + "'"
    querycursor.execute(query)
    for i in querycursor:
        results = i
        details = i.cursor_description

    return results, details


def getipdetails(ip):
    querycursor = connect()
    query = "SELECT * FROM iptable WHERE address = '" + ip + "'"
    querycursor.execute(query)
    for i in querycursor:
        results = i
        details = i.cursor_description
    return results, details


def getspeed(transaction1, transaction2):
    transaction1, details = getdetails(transaction1)
    transaction2, details = getdetails(transaction2)
    lat1 = 0
    lat2 = 0
    long1 = 0
    long2 = 0
    timem = 0
    distancem = 0
    for i in range(len(details)):
        if "transactiontime" in details[i]:
            unixtime = abs(int(transaction1[i]) - int(transaction2[i]))
            timem = unixtime / 3600.

        elif "ip" in details[i]:
            ipses, res = getipdetails(transaction1[i])
            ipses2, res = getipdetails(transaction2[i])
            for j in range(len(res)):
                if "lat" in res[j]:
                    lat1 = float(ipses[j])
                    lat2 = float(ipses[j])
                if "long" in res[j]:
                    long1 = float(ipses[j])
                    long2 = float(ipses2[j])

            coord1 = (lat1, long1)
            coord2 = (lat2, long2)
            distancem = geopy.distance.geodesic(coord1, coord2).km

    speed = distancem / timem
    return speed


transaction1 = "a3fbf9e30c1b"
transaction2 = "d3d9fa40e977"
speedfinal = getspeed(transaction1, transaction2)


if speedfinal > 500:
    score = 100
elif speedfinal > 130:
    score = 75
elif speedfinal > 100:
    score = 50
elif speedfinal > 60:
    score = 25
else:
    score = 0

f = open("check2transresult.txt", "w")
f.write(str(score))
f.close()
import pyodbc
import json


conn = pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                      'Server=79.113.62.81, 1234;'
                      'Database=seonchallenge;'
                      'UID=user;'
                      'PWD=admin;'
                      )
cursor = conn.cursor()
cursor.execute('SELECT * FROM iptable')
rows = [x for x in cursor]
cols = [x[0] for x in cursor.description]
transactions = []
for row in rows:
  transaction = {}
  for prop, val in zip(cols, row):
    transaction[prop] = val
  transactions.append(transaction)

songsJSON = json.dumps(transactions)
print(songsJSON)
import pyodbc

conn = pyodbc.connect('Driver={SQL Server Native Client 11.0};'
                      'Server=79.113.62.81, 1234;'
                      'Database=seonchallenge;'
                      'UID=user;'
                      'PWD=admin;'
                      )
cursor = conn.cursor()
cursor.execute('SELECT * FROM transtable')

for i in cursor:
    print(i.cursor_description)